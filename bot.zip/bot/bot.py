import logging
import asyncio
import sys
from aiogram import *
from aiogram.types import *
from config import TOKEN
from buttons import main_menu, share_contact, back, yes_no
from states import menu, moshina
from aiogram.filters import *
from aiogram.enums import ParseMode
from aiogram.fsm.context import *
from aiogram.fsm.storage.memory import *

router = Router()
bot = Bot(token=TOKEN, parse_mode=ParseMode.HTML)


@router.message(CommandStart())
async def start(message: Message, state: FSMContext):
    await message.answer(text="Menyu", reply_markup=main_menu)
    await state.set_state(menu.choice)


# @router.message(moshina.choice, F.text == "Moshina sotish")
# async def get_name(message: Message, state=FSMContext):
#     await message.answer(text="Ismingizni kiriting", reply_markup=back)
#     await state.set_state(moshina.Mashina_modeli)


@router.message(F.text == "Menyuga qaytish")
async def back_to_menu(message: Message, state=FSMContext):
    await message.answer(text="Menyu", reply_markup=main_menu)
    await state.set_state(moshina.choice)


@router.message(menu.choice, F.text=="Moshina sotish")
async def get_model(message: Message, state: FSMContext):
    await message.answer(text="Qanday modeldegi moshina", reply_markup=back)
    await state.set_state(moshina.Pozitsiya)


@router.message(moshina.Pozitsiya, F.text)
async def get_position(message: Message, state: FSMContext):
    model = message.text
    await state.update_data({'model': model})
    await message.answer(text="Nechinchi pozitsiya",
                         reply_markup=back)
    await state.set_state(moshina.Kraska)


@router.message(moshina.Kraska, F.text)
async def get_kraska(message: Message, state: FSMContext):
    pozitsiya= message.text
    await state.update_data({'pozitsiya': pozitsiya})
    await message.answer(
        text="Kraska qaysi joylarida bor",
        reply_markup=back)
    await state.set_state(moshina.Rangi)


@router.message(moshina.Rangi, F.text)
async def get_color(message: Message, state: FSMContext):
    kraska = message.text
    await state.update_data({'kraska': kraska})
    await message.answer(
        text="Ranggi qanday", 
        reply_markup=back)
    await state.set_state(moshina.Yil)


@router.message(moshina.Yil, F.text)
async def get_years(message: Message, state: FSMContext):
    rangi = message.text
    await state.update_data({'rangi': rangi})
    await message.answer(
        text="Nechenchi yil moshinasi",
        reply_markup=back)
    await state.set_state(moshina.Probeg)


@router.message(moshina.Probeg, F.text)
async def get_probeg(message: Message, state: FSMContext):
    yil = message.text
    await state.update_data({'yil': yil})
    await message.answer(
        text="Moshina qancha yurgan",
        reply_markup=back)
    await state.set_state(moshina.Narxi)



@router.message(moshina.Narxi, F.text)
async def get_price(message: Message, state: FSMContext):
    probeg = message.text
    await state.update_data({'probeg': probeg})
    await message.answer(
        text="Narxini yozing",
        reply_markup=back)
    await state.set_state(moshina.Tel)


@router.message(moshina.Tel, F.text)
async def get_number(message: Message, state: FSMContext):
    narxi = message.text
    await state.update_data({'narxi': narxi})
    await message.answer(
        text="nomeringizni yozing",
        reply_markup=back)
    await state.set_state(moshina.Qayerniki)


@router.message(moshina.Qayerniki, F.text)
async def qayerniki(message:Message,state:FSMContext):
    tel = message.text
    await state.update_data({'tel': tel})
    await message.answer(text="Qayerniki ?",reply_markup=back)
    await state.set_state(moshina.final)
    

@router.message(moshina.final, F.text)
async def yes_or_no(message: Message, state: FSMContext):
    qayerniki = message.text
    await state.update_data({'qayerniki': qayerniki})
    data = await state.get_data()



    model = data.get('model')
    pozitsiya = data.get('pozitsiya')
    kraska = data.get('kraska')
    rangi = data.get('rangi')
    yil = data.get('yil')
    probeg= data.get('probeg')
    narxi = data.get('narxi')
    tel = data.get('tel')
    qayerniki = data.get('qayerniki')
    await message.answer(
       text=f"🚘 Moshina modeli: {model}\n🔢 Pozitsiya: {pozitsiya}\n🔄 Kraska: {kraska}\n♻️ Rangi: {rangi}\n📶 Yil: {yil}\n🆙 Probeg: {probeg}\n💲 Narxi: {narxi}\n📞Tel:: {tel}\n🚩Qayerniki: {qayerniki}\n")
    await message.answer("Ariza yuborilsinmi ?", reply_markup=yes_no)
    await state.set_state(moshina.choice)


@router.message(moshina.choice, F.text == "Ha")
async def car_yes(message: Message, state: FSMContext):
    data = await state.get_data()

    model = data.get('model')
    pozitsiya = data.get('pozitsiya')
    kraska = data.get('kraska')
    rangi = data.get('rangi')
    yil = data.get('yil')
    probeg= data.get('probeg')
    narxi = data.get('narxi')
    tel = data.get('tel')
    qayerniki = data.get('qayerniki')
    await bot.send_message(
        chat_id='-1002044419402',
        text=f"🚘 Moshina modeli: {model}\n🔢 Pozitsiya: {pozitsiya}\n🔄 Kraska: {kraska}\n♻️ Rangi: {rangi}\n📶 Yil: {yil}\n🆙 Probeg: {probeg}\n💲 Narxi: {narxi}\n📞Tel:: {tel}\n🚩Qayerniki: {qayerniki}\n")
    await message.answer("Ariza yuborildi", reply_markup=main_menu)
    await state.set_state(menu.choice)


@router.message(moshina.choice, F.text == "Yo'q")
async def car_no(message: Message, state: FSMContext):
    await message.answer("Menyu", reply_markup=main_menu)
    await state.set_state(menu.choice)


async def main():
    dp = Dispatcher()

    dp.include_router(router=router)
    await dp.start_polling(bot)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    asyncio.run(main())
