from aiogram.fsm.state import *


class menu(StatesGroup):
    choice = State()


class moshina(StatesGroup):
    Mashina_modeli = State()
    Pozitsiya = State()
    Kraska = State()
    Rangi = State()
    Yil = State()
    Probeg= State()
    Narxi=State()
    Tel=State()
    Qayerniki=State()
    final=State()
    yesno=State()
    choice=State()
